# Digitech Algorithm — Android Prototype v0.2

Includes:
- TradingView live chart embed
- Crypto, Forex, Gold, NSE/BSE-oriented symbols and major indices
- Multi-timeframe selector
- ICT checklist dashboard: swings, liquidity, MSS/BOS/CHoCH, FVG/IFVG, OB/Breaker/Mitigation, Premium/Discount/OTE, sessions, AMD/PO3, risk
- `ICT_ENGINE_REFERENCE.pine` containing a programmable reference for swing structure, MSS and FVG logic.

Important:
The embedded TradingView chart is live, but a WebView cannot simply read TradingView's private chart data. Production-grade automatic signals require a permitted OHLC/market-data feed (and potentially TradingView/broker licensing) that is connected to the ICT engine. The current dashboard therefore does not claim live signals from the chart.

No trading algorithm can honestly guarantee 100% wins. Backtesting and paper trading are required before any live order execution.


## Real-money auto-trading
The app now includes a guarded Auto-Trade configuration UI. Direct broker credentials and order execution are intentionally not embedded in the Android WebView. For real-money execution, connect a secure server-side broker adapter over HTTPS, implement authentication, idempotent order submission, order-status reconciliation, position sizing, daily loss limits, max-open-trade limits, and an emergency kill switch. The UI does not claim that a broker connection is active until such a service is configured.
