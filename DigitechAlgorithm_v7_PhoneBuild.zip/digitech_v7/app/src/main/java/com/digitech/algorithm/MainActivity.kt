package com.digitech.algorithm

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.content.Intent

class MainActivity : Activity() {
    private var filePathCallback: ValueCallback<Array<android.net.Uri>>? = null
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView, filePath: ValueCallback<Array<android.net.Uri>>, fileChooserParams: FileChooserParams): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath
                return try {
                    startActivityForResult(fileChooserParams.createIntent(), 1001)
                    true
                } catch (e: Exception) { filePathCallback = null; false }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }
    override fun onBackPressed() {
        val web = (window.decorView.findViewById(android.R.id.content) as android.view.ViewGroup)
        super.onBackPressed()
    }
}
