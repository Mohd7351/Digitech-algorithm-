plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.digitech.algorithm"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.digitech.algorithm"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
